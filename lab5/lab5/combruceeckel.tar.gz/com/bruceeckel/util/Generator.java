//: com:bruceeckel:util:Generator.java
// From 'Thinking in Java, 2nd ed.' by Bruce Eckel
// www.BruceEckel.com. See copyright notice in CopyRight.txt.
package com.bruceeckel.util;
public interface Generator { 
  Object next(); 
} ///:~